package oe.lesson1;

public class Rectangle implements Shape{
    //Default visibility is package-private! You have to set private visibility explicitly.
    private double a;
    private double b;

    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }

    @Override //Annotation: metadata for the compiler; doesn't add extra function to the program, not mandatory
    public double getArea() {
        return a*b;
    }

    @Override
    public double getCircumference() {
        return 2*(a+b);
    }

}
