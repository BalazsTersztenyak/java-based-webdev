package oe.lesson1;

public class Square extends Rectangle{
    public Square(double a) {
        super(a, a); //Calling the Rectangle constructor (super: reference to the base class)
    }
}
