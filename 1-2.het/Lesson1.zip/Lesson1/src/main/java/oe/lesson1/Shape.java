package oe.lesson1;

public interface Shape {
    double getArea();
    double getCircumference();
}
