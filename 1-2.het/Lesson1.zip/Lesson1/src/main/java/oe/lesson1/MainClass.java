package oe.lesson1;

import java.util.ArrayList;
import java.util.Arrays;

public class MainClass {
    public static void main(String[] args) {
        System.out.println("Hello World");
        int radius=3;
        double circumference=2*radius*Math.PI;
        System.out.println(circumference);

        double area=Math.pow(radius, 2)*Math.PI;

        //String formatting:
        //-create formatted string: String.format
        //-write formatted string to console: printf
        // %d is integer, %f is floating point number, %s is text (insert as string), %n is platform-specific new line char
        System.out.println(String.format("The area of the circle is %s", area));
        System.out.printf("The area of the circle is %s%n", area); // full fractional part
        System.out.printf("The area of the circle is %f%n", area); // default precision
        System.out.printf("The area of the circle is %.4f%n", area); // 4 digits precision
        System.out.printf("The area of the circle is %10.4f%n", area); // 10 digits width (total number of digits)
        System.out.printf("The area of a %d radius circle is %.4f%n",radius, area);
        System.out.printf("The area of a %2$d radius circle is %1$.4f%n",area,radius);// explicit ordering
        System.out.printf("The area of a %2$4d radius circle is %1$.4f%n",area,radius); // 4 digits width for integer
        System.out.printf("The area of a %2$04d radius %3$9s is%n %1$.4f%n",area,radius,"circle");

        // 2. Concatenate odd numbers from 1 to 9 into a string

        //String s="";
        StringBuilder sb=new StringBuilder();
        for (int i = 1; i < 10; i+=2) {
            //s+=i+" ";
            sb.append(i).append(" ");
        }
        String result=sb.toString();
        System.out.println(result);

        //Check if result is correct

        //This doesn't work here, because == means reference-equality!!!
        //if (result=="1 3 5 7 9 ") System.out.println("Correct!");

        //To compare strings, use equals or equalsIgnoreCase
        if (result.equals("1 3 5 7 9 ")) System.out.println("Correct!");

        String a="apple";
        System.out.println("APPle".equalsIgnoreCase(a));

        // 3. Create classes for shapes, calculate area and circumference.
        Shape[] shapes=new Shape[3];
        shapes[0]=new Rectangle(1,2);
        shapes[1]=new Square(4);
        shapes[2]=new Rectangle(3,4);

        for (Shape shape : shapes) {
            System.out.println("Circumference: "+shape.getCircumference());
            System.out.println("Area: "+shape.getArea());
            if (shape instanceof Square){ //If this array element is an instance of the Square class...
                System.out.println("This is a square.");
            }
        }

        /*
        ArrayList<Shape> shapesList=new ArrayList<>();
        shapesList.addAll(Arrays.asList(shapes));
        shapesList.stream().filter(s->s.getArea()>10).forEach(s-> System.out.println("Area: "+s.getArea()));
         */
    }
}
