package com.elsoora.teljes;

public class Negyzet implements ISikidom {
    double oldal;

    /**
     * Négyzet síkidom.
     * @param oldal oldal hossza.
     */
    public Negyzet(double oldal) {
        this.oldal = oldal;
    }

    @Override
    public double terulet() {
        return Math.pow(oldal,2);
    }

    @Override
    public double kerulet() {
        return 4*oldal;
    }
}
