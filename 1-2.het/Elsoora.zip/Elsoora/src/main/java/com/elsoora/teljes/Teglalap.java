package com.elsoora.teljes;

public class Teglalap implements ISikidom {

    double a, b;

    public Teglalap(double a, double b) {
        this.a = a;
        this.b = b;
    }

    /**
     * Minden síkidomnak van terület, de azt csak az adott tudja, hogyan kell kiszámolni. Paraméter nem kell, mert az objektum már tartalmazza az adatokat.
     */
    @Override
    public double terulet() {
        return a * b;
    }

    /**
     * Minden síkidomnak van kerülete, de azt csak az adott tudja, hogyan kell kiszámolni. Paraméter nem kell, mert az objektum már tartalmazza az adatokat.
     */
    @Override
    public double kerulet() {
        return 2 * (a + b);
    }
}
