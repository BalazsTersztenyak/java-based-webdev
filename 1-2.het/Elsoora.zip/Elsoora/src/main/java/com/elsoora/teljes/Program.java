package com.elsoora.teljes;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        ISikidom[] tomb = new ISikidom[2];
        Scanner sc = new Scanner(System.in);
        System.out.println("Hogy hívnak?");
        System.out.println("Hello! " + sc.nextLine());
        System.out.println("Sikidomok paramétereinek megadása:\nNégyzet a oldalának hossza!");
        tomb[0] = new Negyzet(Double.parseDouble(sc.nextLine()));
        //természetesen le lehet meneteni a megkapott értékeket külön külön is.
        // sc.nextDouble azonnal átalakítja doublere az értéket!

        System.out.println("Téglalap a majd b oldalának hossza!");
        tomb[1] = new Teglalap(sc.nextDouble(), sc.nextDouble());
        StringBuilder sb = new StringBuilder("Eredmények:");

        for (int i = 0; i < tomb.length; i++) {
            sb.append("\n");
            sb.append(tomb[i].toString()); //ez az alapértelmezett toString()
            sb.append("\n");
            sb.append(String.format("kerület: %.2f", tomb[i].kerulet()));
            sb.append("\n");
            sb.append(String.format("terulet: %.2f", tomb[i].terulet()));
            sb.append("\n");
        }

        System.out.println(sb);

    }
}
