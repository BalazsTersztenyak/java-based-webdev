package com.elsoora.teljes;

public interface ISikidom {
    /**
     * Minden síkidomnak van terület, de azt csak az adott tudja, hogyan kell kiszámolni. Paraméter nem kell, mert az objektum már tartalmazza az adatokat.
     */
    double terulet();

    /**
     * Minden síkidomnak van kerülete, de azt csak az adott tudja, hogyan kell kiszámolni. Paraméter nem kell, mert az objektum már tartalmazza az adatokat.
     */
    double kerulet();
}
