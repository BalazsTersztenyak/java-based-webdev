package oe.initblocks;

public class MainClass {
    public static void main(String[] args) {
        BaseClass base=new BaseClass();
        System.out.println("---------------");
        SubClass sub=new SubClass();
    }
}
