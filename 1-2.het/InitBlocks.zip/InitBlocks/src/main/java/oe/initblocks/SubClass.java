package oe.initblocks;

public class SubClass extends BaseClass{
    static {
        System.out.println("Subclass static init block");
    }

    {
        System.out.println("Subclass instance init block");
    }

    public SubClass() {
        System.out.println("Subclass constructor");
    }
}
