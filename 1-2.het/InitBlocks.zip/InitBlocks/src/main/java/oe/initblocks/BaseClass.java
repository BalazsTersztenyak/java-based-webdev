package oe.initblocks;

public class BaseClass {
    static {
        System.out.println("Base class static init block 1");
    }

    static {
        System.out.println("Base class static init block 2");
    }

    {
        System.out.println("Base class instance init block");
    }

    public BaseClass() {
        System.out.println("Base class constructor");
    }
}
