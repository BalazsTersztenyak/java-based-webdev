/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oe.collectionexamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeSet;

/**
 *
 * @author GabriellaSimon-Nagy
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person joe=new Person("Joe",25);
        Person jane=new Person("Jane",20);
        Person tom=new Person("Tom",42);
        Person mary=new Person("Mary",6);
        
       
        System.out.println("- ArrayList"); //ArrayList: a resizable array
        ArrayList<Person> aList=new ArrayList();
        aList.add(joe);
        aList.add(jane);
        aList.add(jane);
        aList.add(tom);
        aList.add(1, mary);
        for (Person person : aList) {
            System.out.println(person.getName());
        }
        System.out.println("--- ArrayList after change");
        aList.set(0,new Person("Jim",60));
        for (int i = 0; i < aList.size(); i++) {
            System.out.println(aList.get(i).getName());
        }
        //Arrays.asList creates a fix-sized list! It is not a real ArrayList.
        System.out.println("--- Arrays.asList: fix-sized list");
        List<Person> test=Arrays.asList(joe, jane, tom, mary);
        System.out.println(test.getClass()); // class java.util.Arrays$ArrayList
        System.out.println(aList.getClass()); // class java.util.ArrayList
        // This works: elements can be changed
        test.set(0,new Person("Jim",60));
        for (Person person : test) {
            System.out.println(person.getName());
        }
        //This does not work! The list is fix-sized.
        try {
            test.add(new Person("Eddie", 50));
        } catch (Exception e) {
            System.out.println("Cannot add element to fix-sized list.");
        }
        
        
        System.out.println("- PriorityQueue"); // PriorityQueue: an ordered queue (not FIFO)
        //add() only works if the correct order can be determined (elements must be Comparable)
        PriorityQueue<Person> queue=new PriorityQueue();
        //Adding a non-comparable element throws ClassCastException
        queue.add(jane);
        queue.add(joe);
        queue.add(mary);
        queue.add(jane);
        queue.add(tom);
        
        System.out.println("--- Peek: read head element");
        System.out.println(queue.peek().getName());
        
        System.out.println("--- Change head element priority");
        queue.peek().setAge(70);
        System.out.println(queue.peek().getName()); //Did not reorder
        queue.add(queue.poll()); //Remove and reinsert
        System.out.println(queue.peek().getName()); //Now it is sorted.
        
        System.out.println("--- Poll: read and remove head element");
        Person p;
        while ((p=queue.poll())!=null) {
            System.out.printf("%s (%d)%n",p.getName(), p.getAge());
        }
        System.out.println("Queue size: "+queue.size());
        
        
        System.out.println("- LinkedList");
        //LinkedList: both a List and a Queue
        LinkedList<Person> lList=new LinkedList();
        lList.add(joe);
        lList.add(joe);
        lList.add(jane);
        lList.add(tom);
        //Elements can be added at a specific index like in a List
        lList.add(1, mary);
        for (Person person : lList) {
            System.out.println(person.getName());
        }
        System.out.println("--- LinkedList as Queue:");
        //It can be used as a Queue (no priority here, just simple FIFO)
        System.out.println("Peek: "+lList.peek().getName());
        while ((p=lList.poll())!=null) {
            System.out.printf("%s (%d)%n",p.getName(), p.getAge());
        }
        
        
        System.out.println("- TreeSet");
        //TreeSet is a sorted set (elements are ordered, duplications are not allowed)
        TreeSet<Person> tSet=new TreeSet();
        tSet.add(joe);
        tSet.add(jane);
        tSet.add(joe); // Joe will show up only once.
        tSet.add(tom);
        tSet.add(mary);
        for (Person person : tSet) {
            System.out.println(person.getName());
        }
        
        Person newPerson=new Person("Adam",40);
        
        System.out.println("--- All the people younger than Adam:");
        for (Person person : tSet.headSet(newPerson)) {
            System.out.println(person.getName());
        }
        System.out.println("--- The youngest person older than Adam:");
        System.out.println(tSet.higher(newPerson).getName());
        
        
        System.out.println("- HashMap");
        HashMap<Integer,Person> hMap=new HashMap();
        hMap.put(111, joe);
        hMap.put(112, jane);
        hMap.put(113, tom);
        hMap.put(114, mary);
        for (Map.Entry<Integer, Person> entry : hMap.entrySet()) {
            System.out.printf("%d: %s%n",entry.getKey(),entry.getValue().getName());
        }
        System.out.println("--- HashMap: get element value for key 112");
        System.out.println(hMap.get(112).getName());
        
        System.out.println("--- HashMap after changes");
        hMap.put(111, new Person("Adam",40));
        hMap.putIfAbsent(114, new Person("Elizabeth",90));
        for (Map.Entry<Integer, Person> entry : hMap.entrySet()) {
            System.out.printf("%d: %s%n",entry.getKey(),entry.getValue().getName());
        }
    }
    
}
