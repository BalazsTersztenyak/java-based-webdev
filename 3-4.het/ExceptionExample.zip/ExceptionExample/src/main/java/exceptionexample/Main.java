/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionexample;

/**
 *
 * @author GabriellaSimon-Nagy
 */
public class Main {
    public static void main(String[] args) {
        try {
            Hello("Shakespeare");
        } catch (CoronaException ex) {
            System.out.println("Run you fools!");
        } catch (ShakespeareException ex){
            System.out.println("To be or not to be?");
        }
    }
    
    static void Hello(String nev) throws CoronaException{
        if (nev.equals("Coronavirus")){
            throw new CoronaException();
        }
        if (nev.equals("Shakespeare")){
            throw new ShakespeareException();
        }
        System.out.println("Hello "+nev);
    }
}
