/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oe.streamapiexamples;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author GabriellaSimon-Nagy
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Person> aList=new ArrayList();
        aList.add(new Person("Joe",25));
        aList.add(new Person("Jane",20));
        aList.add(new Person("Tom",42));
        aList.add(new Person("Mary",6));
        aList.add(new Person("Eddie",75));
        
        System.out.println("-Stream basics");
        aList.stream().forEach(System.out::println); // :: is method reference operator
        //Same as:
        //aList.stream().forEach(p->System.out.println(p));
        
        //Convert stream back to List: collect(Collectors.toList())
        /*for (Person p : aList.stream().collect(Collectors.toList())) {
            System.out.println(p);
        }*/
        
        System.out.println("-Stream ordering");
        aList.stream().sorted(Comparator.comparing(Person::getAge).reversed()).forEach(System.out::println);
        
        System.out.println("-Stream filtering");
        aList.stream().filter(p->p.getAge()>40).forEach(System.out::println);
        
        System.out.println("-Stream mapping");
        aList.stream().map(p->p.getName()).forEach(System.out::println);
        
        System.out.println("-Names of people younger than 50, order by name. Collect names into a single string.");
        String names=aList.stream()
                .filter(p->p.getAge()<50)
                .map(p->p.getName())
                .sorted() //You don't have to specify a Comparator because at this point we only have the names as strings
                .collect(Collectors.joining(", "));
        System.out.println(names);
        
        System.out.println("-Aggregation");
        //Number of people whose names start with "J":
        System.out.println(aList.stream().filter(p->p.getName().startsWith("J")).count());
        //Youngest person:
        System.out.println(aList.stream().min(Comparator.comparing(Person::getAge)).get());
        //Average and sum age:
        System.out.println(aList.stream().collect(Collectors.averagingInt(Person::getAge)));
        System.out.println(aList.stream().collect(Collectors.summingInt(Person::getAge)));
        
        System.out.println("-Grouping");
        var grouping=aList.stream().collect(Collectors.groupingBy(p->p.getAge()/10));
        for (Map.Entry<Integer, List<Person>> entry : grouping.entrySet()) {
            System.out.printf("%d0-s: %s%n",entry.getKey(),
                    entry.getValue().stream().map(p->p.getName()).collect(Collectors.joining(",")));
        }
    }
    
}
