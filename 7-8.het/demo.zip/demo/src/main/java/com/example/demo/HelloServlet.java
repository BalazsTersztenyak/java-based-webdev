package com.example.demo;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        // Hello
        PrintWriter out = response.getWriter();
        // ezzel írunk a honlapra stringet,
        // így nem ismeri fel a html utasításokat!
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Tax Calculation Results</title>");
        out.println("</head>");
        out.println("<body>");
        String nev = request.getParameter("nev"); // küldő "nev" paraméter értékének lekérése
        String salstring=request.getParameter("salary");
        if (!salstring.isEmpty()){ // üres-e
            int sal=Integer.parseInt(salstring);
            double tax=sal*0.15;
            out.printf("<p>The income tax for a %d HUF salary is %.2f HUF.</p>%n",sal,tax);
        } else{
            out.println("<p>Salary unknown, tax calculation failed.</p>");
        }

        out.println("<a href=\"index.jsp\">Back to the calculator</a>"); // link az index.jsp-re
        out.println("</body></html>");
    }

    public void destroy() {
    }
}