package Program;

import jakarta.xml.bind.annotation.XmlRootElement;

//Ez kell az XMLbe íráshoz!
@XmlRootElement
public class Student {
    private String nev;
    private float atlag;
    private int kor;

    public Student(String nev, float atlag, int kor) {
        this.nev = nev;
        this.atlag = atlag;
        this.kor = kor;
    }

    public Student() {
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public float getAtlag() {
        return atlag;
    }

    public void setAtlag(float atlag) {
        this.atlag = atlag;
    }

    public int getKor() {
        return kor;
    }

    public void setKor(int kor) {
        this.kor = kor;
    }

    //hogy könnyű legyen feldolgozni a kimenetet.
    @Override
    public String toString() {
        return this.nev + "\t" + this.atlag + "\t" + this.kor;
    }
}
