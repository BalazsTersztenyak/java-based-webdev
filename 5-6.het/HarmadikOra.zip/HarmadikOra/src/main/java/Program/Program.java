package Program;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Program {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();
        students.add(new Student("A", 5.0f, 20));
        students.add(new Student("B", 4.0f, 20));
        students.add(new Student("C", 3.0f, 20));

        //Writer(students);
        //Reader();
        //XMLSer(students);
        Gson(students);
    }

    //Fájl írása, fontos a try()<-Író, olvasó
    private static void Writer(List<Student> students) {
        try (var pw = new PrintWriter("test.txt")) {
            for (var stud : students
            ) {
                pw.println(stud);
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

        try {
            Files.write(Paths.get("testr"),
                    students.stream().map(Student::toString).
                            collect(Collectors.toList()),
                    StandardOpenOption.CREATE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Fájl beolvasása
    private static void Reader() {
        try (var br = Files.newBufferedReader(
                Paths.get("test.txt"))) {
            var lines = br.lines().collect(Collectors.toList());
            String[] arr;
            for (var line : lines
            ) {
                arr = line.split("\t");
                System.out.println(
                        new Student(
                                arr[0],
                                Float.parseFloat(arr[1]),
                                Integer.parseInt(arr[2])
                        ));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //XML írása és feldolgozása,
    // Student osztály @XmlRootElement jelölése
    private static void XMLSer(List<Student> students) {
        try {
            JAXBContext ctx = JAXBContext.newInstance(Student.class);
            Marshaller m = ctx.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.marshal(students.get(0), System.out);

            m.marshal(students.get(0),
                    Files.newOutputStream(Paths.get("test.xml")));

            Unmarshaller um = ctx.createUnmarshaller();
            var a = um.unmarshal(Files.newInputStream(Paths.get("test.xml")));
            System.out.println((Student) a);

        } catch (JAXBException | IOException e) {
            System.out.println(e.getMessage());
        }
    }

    //json fájl írása, feldolgozása
    private static void Gson(List<Student> students) {
        System.out.println(new Gson().toJson(students));
        System.out.println(new GsonBuilder().
                setPrettyPrinting()
                .serializeNulls()
                .create()
                .toJson(students));

        try (var bw = Files.newBufferedWriter(Paths.get("test.json"))) {
            bw.write(new Gson().toJson(students));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (var br = Files.newBufferedReader(Paths.get("test.json"))) {
            var a = new Gson().fromJson(br,
                    ArrayList.class);
            System.out.println(a);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
